

package com.org.InventoryManagement.entity;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;
@Data
@Entity
@Table(name="InventorySalesTbl")
public class Sales {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column
	private long id;
	@Column(name="product_id")
	private String Pid;
	@Column(name="product_name")
	private String ProductName;
	@Column(name="purchase_date")
	private String Pdate;
	@Column(name="vendor_name")
	private String VendorName;
	@Column(name="product_qty")
	private String Pqty;
	@Column(name="product_price")
	private String Pprice;
	
	
	public String getPqty() {
		return Pqty;
	}


	public void setPqty(String pqty) {
		Pqty = pqty;
	}


	public String getPid() {
		return Pid;
	}


	public void setPid(String pid) {
		Pid = pid;
	}


	public String getProductName() {
		return ProductName;
	}


	public void setProductName(String productName) {
		ProductName = productName;
	}




	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}




	public String getPdate() {
		return Pdate;
	}


	public void setPdate(String pdate) {
		Pdate = pdate;
	}


	public String getVendorName() {
		return VendorName;
	}


	public void setVendorName(String vendorName) {
		VendorName = vendorName;
	}


	public String getPprice() {
		return Pprice;
	}


	public void setPprice(String pprice) {
		Pprice = pprice;
	}


	public Sales(long id,String ProductName,String Pqty, String Pid,String Pdate, String VendorName, String Pprice) {
		super();
		this.id = id;
		this.ProductName=ProductName;
		this.Pqty=Pqty;
		this.VendorName=VendorName;
		this.Pid=Pid;
		this.Pprice = Pprice;
		this.Pdate = Pdate;
		
	}


	@Override
	public String toString() {
		return "Invoice [id=" + id + ", ProductName=" + ProductName + ", Pqty=" + Pqty + ", VendorName=" + VendorName
				+ ", Pid=" + Pid + ", Pprice=" + Pprice +",Pdate=" + Pdate +"]";
	}


	public Sales() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
