package com.org.InventoryManagement.controller;


import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.org.InventoryManagement.entity.Sales;
import com.org.InventoryManagement.service.SalesService;
@RestController
@RequestMapping("/api/inventorysales")
public class SalesController {
	private SalesService salesService;


	public SalesController(SalesService salesService) {
		super();
		this.salesService = salesService;
	}
	
	@PostMapping
	public ResponseEntity<Sales> saveSales(@RequestBody Sales sales) {
		return new ResponseEntity<Sales>(salesService.saveSales(sales),HttpStatus.CREATED);
	}
	

	@GetMapping("/all")
	public List<Sales> getAllSales()
	{
		return salesService.getAllSales();
	}
	@GetMapping("{id}")
	public ResponseEntity<Sales>getSalesById(@PathVariable("id") long id) {
		return new ResponseEntity<Sales>(salesService.getSalesById(id), HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Sales> updateSales(@PathVariable("id") long id, @RequestBody Sales sales){
		
		return new ResponseEntity<Sales>(salesService.updateSales(sales, id),HttpStatus.OK);
		
	}
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteSales(@PathVariable("id") long id){
		salesService.deleteSalesById(id);
		return new ResponseEntity<String> ("Purchase  Record Is Deleted", HttpStatus.OK);
	}
	
}
