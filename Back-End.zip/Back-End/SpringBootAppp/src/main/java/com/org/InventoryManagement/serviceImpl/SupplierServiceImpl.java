

package com.org.InventoryManagement.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.org.InventoryManagement.entity.Supplier;
import com.org.InventoryManagement.exception.ResourceNotFound;
import com.org.InventoryManagement.repository.SupplierRepository;
import com.org.InventoryManagement.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService{

	private SupplierRepository supplierRepository;
	
	
	public SupplierServiceImpl(SupplierRepository supplierRepository) {
		super();
		this.supplierRepository = supplierRepository;
	}


	@Override
	public Supplier saveSupplier(Supplier supplier) {
		return supplierRepository.save(supplier);
	}


	@Override
	public List<Supplier> getAllSupplier() {
		return supplierRepository.findAll();
		
	}


	@Override
	public Supplier getSupplierById(long id) {
		Optional<Supplier> supplier = supplierRepository.findById(id);
		if(supplier.isPresent()) {
			return supplier.get();
		}
		else {
          
			throw new ResourceNotFound("Supplier","Id",id);
		}
		
	}


	@Override
	public Supplier updateSupplier(Supplier supplier, long id) {
		Supplier sup = new Supplier();
	 try {
		   sup = supplierRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Supplier","Id",id));
	} catch (ResourceNotFound e) {
		
		e.printStackTrace();
	}
	 sup.setFirstName(supplier.getFirstName());
	 sup.setLastName(supplier.getLastName());
	 sup.setEmail(supplier.getEmail());
	 sup.setContactNo(supplier.getContactNo());
	 sup.setAddress(supplier.getAddress());
	
	 supplierRepository.save(sup);
	return sup;
	}

	@Override
	public void deleteSupplier(long id) {
		supplierRepository.findById(id).orElseThrow(()-> new ResourceNotFound("Supplier", "Id", id));
		supplierRepository.deleteById(id);
		
	}


	@Override
	public void deleteSupplierById(long id) {
		//this.supplierRepository.deleteById(id);
		supplierRepository.deleteById(id);		//return;
	}


	


	

		
	
	

}
