

package com.org.InventoryManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.InventoryManagement.entity.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier,Long>{

}
