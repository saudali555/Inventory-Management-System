

package com.org.InventoryManagement.serviceImpl;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.org.InventoryManagement.entity.Sales;
import com.org.InventoryManagement.exception.ResourceNotFound;
import com.org.InventoryManagement.repository.SalesRepository;
import com.org.InventoryManagement.service.SalesService;

@Service
public class SalesServiceImpl implements SalesService{

	private SalesRepository salesRepository;
	
	
	public SalesServiceImpl(SalesRepository salesRepository) {
		super();
		this.salesRepository = salesRepository;
	}


	@Override
	public Sales saveSales(Sales sales) {
		return salesRepository.save(sales);
	}


	@Override
	public List<Sales> getAllSales() {
		return salesRepository.findAll();
		
	}


	@Override
	public Sales getSalesById(long id) {
		Optional<Sales> sales = salesRepository.findById(id);
		if(sales.isPresent()) {
			return sales.get();
		}
		else {
          
			throw new ResourceNotFound("Sales","Id",id);
		}
		
	}


	@Override
	public Sales updateSales(Sales sales, long id) {
		Sales sale1 = new Sales();
	 try {
		   sale1 = salesRepository.findById(id).orElseThrow(
				 ()-> 		 new ResourceNotFound("Sales","Id",id));
	} catch (ResourceNotFound e) {
		
		e.printStackTrace();
	}
	 sale1.setPid(sales.getPid());
	 sale1.setPdate(sales.getPdate());
	 sale1.setProductName(sales.getProductName());
	 sale1.setVendorName(sales.getVendorName());
	 sale1.setVendorName(sales.getVendorName());
	 sale1.setPqty(sales.getPqty());
	 sale1.setPprice(sales.getPprice());
	 
	
	
	 salesRepository.save(sale1);
	return sale1;
	}
	@Override
	public void deleteSalesById(long id) {
		salesRepository.findById(id).orElseThrow(()-> new ResourceNotFound("Sales", "Id", id));
	    salesRepository.deleteById(id);
	
		
	}








}