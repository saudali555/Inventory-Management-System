package com.org.InventoryManagement.service;

import java.util.List;


import com.org.InventoryManagement.entity.Sales;

public interface SalesService {
	
	Sales saveSales(Sales sales);
	List<Sales> getAllSales();
	Sales getSalesById(long id);
	Sales updateSales(Sales sales, long id);
	void deleteSalesById(long id);

}
